#include "resource.h"

int main()
{
    csh();
    welcome();
    end();
    return 0;
}
